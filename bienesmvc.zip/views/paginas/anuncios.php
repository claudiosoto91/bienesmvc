<section class="seccion contenedor">
        <h2>Casas y Departamentos en Venta</h2>
        <?php
            include 'listado.php'; 
        ?>

</section>