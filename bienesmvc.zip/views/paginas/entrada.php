<main class="contenedor seccion contenido-centrado">
    <h1>Casa en Venta frente al Bosque</h1>
    <picture>
        <source srcset="build/img/destacada.webp" type="image/webp">
        <source srcset="build/img/destacada.jpg" type="image/jpeg">
        <img src="build/img/destacada.jpg" alt="imagen de la propiedad" loading="lazy">
    </picture>
    <p class="informacion-meta">Escrito el: <span>22/11/23</span> por: <span>Admin</span></p>

    <div class="resumen-propiedad">
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure suscipit deserunt eius. Quibusdam officia voluptatem sit esse porro, consectetur quos illo. Veritatis, expedita aliquam. Ex, magni! Natus ad quibusdam delectus accusamus. Ex nostrum debitis numquam vero, corrupti natus doloribus? Debitis fuga consectetur, enim vel nam recusandae odio ipsam, fugiat porro facere reiciendis dolorem maiores est laboriosam impedit cum laudantium obcaecati.</p>
    </div>
</main>